<?php

/**
 * Throws exception if face was not detected in `faceDetect` call.
 */

namespace svay\Exception;

use Exception;

class NoFaceException extends Exception {

}
