<?php
require_once 'config.php';
require_once '../../config.php';
require_once '../../Source/bot.php';