<?php
/*دقت کنید که این فایل نباید ویرایش شود */
$Dev = "**ADMIN**";
$Token = "**TOKEN**";
$Folder_url = "**URL**";
